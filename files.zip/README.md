# Fatima & You 💕

A private little web app for the two of you — photos, a "watch together" YouTube room,
a music player, a day counter, and two mini games (Memory Match + Would You Rather).

## Files
- `index.html` — the whole app (structure + styling)
- `script.js` — the logic. **This is the only file you need to edit** to add your own
  photos, songs, and questions. Open it in any text editor (even Notepad) and look at
  the top section marked "EDIT THESE".
- `images/` — put your photo files here (e.g. `photo1.jpg`)
- `music/` — put your mp3 files here (e.g. `song1.mp3`)

## How to add your own photos and songs
1. Copy your photos into the `images` folder. Name them anything you like.
2. Open `script.js`, find the `PHOTOS` list near the top, and update the filenames
   and captions to match.
3. Do the same for songs in the `music` folder and the `SONGS` list.
4. Save, and open `index.html` in your browser to check it looks right before uploading.

## Host it for free, "forever" — GitHub Pages
GitHub Pages is a free static hosting service. It stays live as long as your GitHub
account and repository exist, and there's no expiry date or hidden cost.

1. Create a free account at github.com if you don't have one.
2. Click **New repository**, name it something like `us` or `fatima-and-you`,
   set it to **Public**, and create it.
3. Upload all these files (`index.html`, `script.js`, the `images` and `music`
   folders with your files inside) using the **Add file → Upload files** button
   in the repo, or via git if you're comfortable with it.
4. Go to the repo's **Settings → Pages**.
5. Under "Build and deployment", set **Source** to "Deploy from a branch",
   branch = `main`, folder = `/ (root)`, then **Save**.
6. Wait about a minute, then refresh — GitHub will show you a live link like:
   `https://yourusername.github.io/us/`
7. That's your permanent link. Share it with Fatima!

A couple of honest notes:
- Keep the repo **private** if you'd rather the photos not be public — but note
  GitHub Pages sites from private repos need a **paid GitHub plan** to stay private
  and still be viewable as a website. If you want it free, the simplest option is a
  public repo with an unguessable name, since nobody can find it without the link.
- The "watch together" feature loads a YouTube video for both of you to press play
  on at the same time on a call — it isn't perfectly synced playback (that needs a
  server), but it works great for movie nights on a video call together.

## Turning it into an APK (Android app) for free
Once your site is live on GitHub Pages, you can wrap it as an installable Android
app with no cost, using one of these free tools:

**Option A — PWABuilder (easiest, no coding)**
1. Go to https://www.pwabuilder.com
2. Paste in your GitHub Pages link and click "Start".
3. Click "Package for Stores" → choose **Android**.
4. Download the generated APK — you can install it directly on an Android phone,
   or send it to Fatima to install (she'll need to allow "install from unknown
   sources" in her phone settings, since it's not from the Play Store).

**Option B — Median.co (also free tier available)**
1. Go to https://median.co
2. Sign up free, paste your site URL, and it will generate a downloadable APK.

Both of these just wrap your website in an app shell, so any updates you make to
the GitHub Pages site will show up automatically — you generally don't need to
regenerate the APK unless you want a new app icon or name.

## Making it feel more personal
- Replace the browser tab title in `index.html` (`<title>Us — Our Little Corner</title>`).
- Add a real start date on the Home tab — it'll remember it and count the days automatically.
- Add more Would You Rather questions in `script.js` — the more personal, the better.
